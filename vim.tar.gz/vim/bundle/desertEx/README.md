### [Link to vim.org](http://www.vim.org/scripts/script.php?script_id=1693)

### Description
The 'desert' color scheme is a good model of low contrast colors with dark gray background which is good to our eyes. This 'desertEx' color scheme enhanced its colors in order to make it much more beautiful, it also provides nearly the same color for the 256-color terminal.

### ScreenShot
![](http://files.myopera.com/mbbill/files/desertex.png)
